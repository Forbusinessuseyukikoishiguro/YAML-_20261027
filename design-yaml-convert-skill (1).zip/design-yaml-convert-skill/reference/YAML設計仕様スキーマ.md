# YAML設計仕様スキーマ

## 基本方針
- 値は数値・色コード・文字列で書く。曖昧な表現（「大きめ」「少し明るい」）は使わない。
- 読み取れない値は `unknown`。推測で埋めない。
- 1ファイル1デザイン。複数画面は `screens` の配列で管理する。

## 記入例

```yaml
meta:
  name: sample-exhibition-lp
  source:
    type: screenshot           # screenshot | pptx | figma_export | canva_export | illustration | brief
    files: ["hero.png", "sections.png"]
  purpose: 個展の告知LP
  license:
    commercial_use: true
    confirmed_by: 依頼者
  created: 2026-10-22

canvas:
  type: web                    # web | print | slide | image | dashboard
  width: 1280                  # px（webの場合）
  unit: px
  orientation: portrait

tokens:
  color:
    primary: "#1F3A5F"
    text: "#1A1A1A"
    background: "#FAFAF7"
    accent: "#C8553D"
  font:
    heading: "Noto Sans JP"    # 利用許諾を assets に記録
    body: "Noto Sans JP"
    size_base: 16
    line_height: 1.7
  space:
    unit: 8
  radius: 4

layout:
  grid: 12
  max_width: 1120
  sections:
    - id: hero
      order: 1
      role: 第一印象と主要メッセージ
    - id: about
      order: 2
      role: 作家紹介
    - id: works
      order: 3
      role: 作品一覧
    - id: access
      order: 4
      role: 会場・日時

components:
  button_primary:
    background: "@tokens.color.primary"
    text: "#FFFFFF"
    min_height: 48
  card:
    radius: "@tokens.radius"

content:
  - section: hero
    heading: "（原文を保存）"
    body: "（原文を保存）"
    source_language: ja
    translated: false

assets:
  - id: hero_image
    type: photo
    rights: 作者本人の撮影・利用許諾あり
    alt: 展示会場の入口の写真
  - id: logo
    type: logo
    rights: unknown
    action: 依頼者に確認

accessibility:
  min_text_contrast: 4.5
  focus_visible: true
  reading_order: [hero, about, works, access]

open_questions:
  - 作品画像の解像度が不明（表示サイズの決定に必要）
  - 会場の住所表記の正式名称
```

## 項目ごとの注意
- `tokens`：色は必ず色コード。実際の画面から読み取った場合は、読み取り方法（スポイト、書き出しデータ等）を `meta` に記録する。
- `layout`：位置は「左上から何割」など相対で書くと、媒体が変わっても使える。
- `content`：原文を変更しない。翻訳した場合は `translated: true` と翻訳者を記録する。
- `assets`：権利が不明なものは `action` で扱いを決める。
